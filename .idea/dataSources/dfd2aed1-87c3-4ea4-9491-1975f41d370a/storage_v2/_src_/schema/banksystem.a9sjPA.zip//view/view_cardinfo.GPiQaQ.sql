create definer = bankmaster@localhost view view_cardinfo as
select `c`.`card_id`        AS `卡号`,
       `u`.`customer_name`  AS `客户名`,
       `c`.`cur_tpye`       AS `货币种类`,
       `d`.`saving_name`    AS `存款类型`,
       `c`.`opendate`       AS `开户日期`,
       `c`.`balance`        AS `余额`,
       `c`.`password`       AS `密码`,
       `c`.`is_report_loss` AS `是否挂失`
from ((`banksystem`.`card` `c` join `banksystem`.`userinfo` `u`
       on ((`c`.`card_id` = `u`.`card_id`))) join `banksystem`.`deposit` `d` on ((`c`.`saving_id` = `d`.`saving_id`)));

-- comment on column view_cardinfo.卡号 not supported: 银行卡号

-- comment on column view_cardinfo.客户名 not supported: 客户开户名称

-- comment on column view_cardinfo.货币种类 not supported: 货币种类，默认人民币

-- comment on column view_cardinfo.存款类型 not supported: 存款类型名字

-- comment on column view_cardinfo.开户日期 not supported: 默认当前时间

-- comment on column view_cardinfo.余额 not supported: 不得低于一元

-- comment on column view_cardinfo.密码 not supported: 默认6个8

-- comment on column view_cardinfo.是否挂失 not supported: 0代表否，1代表是

