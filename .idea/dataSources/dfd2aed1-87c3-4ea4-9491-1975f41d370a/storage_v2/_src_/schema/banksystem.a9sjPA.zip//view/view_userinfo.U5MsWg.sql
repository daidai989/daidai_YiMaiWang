create definer = bankmaster@localhost view view_userinfo as
select `banksystem`.`userinfo`.`customer_id`   AS `用户编号`,
       `banksystem`.`userinfo`.`customer_name` AS `用户姓名`,
       `banksystem`.`userinfo`.`card_id`       AS `银行卡号`,
       `banksystem`.`userinfo`.`identity_id`   AS `身份证号`,
       `banksystem`.`userinfo`.`telephone`     AS `联系电话`,
       `banksystem`.`userinfo`.`address`       AS `地址`
from `banksystem`.`userinfo`;

-- comment on column view_userinfo.用户编号 not supported: 客户编号，主键

-- comment on column view_userinfo.用户姓名 not supported: 客户开户名称

-- comment on column view_userinfo.银行卡号 not supported: 卡号

-- comment on column view_userinfo.身份证号 not supported: 身份证号

-- comment on column view_userinfo.联系电话 not supported: 手机号

-- comment on column view_userinfo.地址 not supported: 地址

