create definer = bankmaster@localhost view view_transinfo as
select `banksystem`.`tradeinfo`.`transdate`  AS `交易日期`,
       `banksystem`.`tradeinfo`.`transtype`  AS `交易类型`,
       `banksystem`.`tradeinfo`.`card_id`    AS `卡号`,
       `banksystem`.`tradeinfo`.`transmoney` AS `交易金额`,
       `banksystem`.`tradeinfo`.`remark`     AS `备注`
from `banksystem`.`tradeinfo`;

-- comment on column view_transinfo.交易日期 not supported: 默认系统当前时间

-- comment on column view_transinfo.交易类型 not supported: 交易类型

-- comment on column view_transinfo.卡号 not supported: 交易卡号

-- comment on column view_transinfo.交易金额 not supported: 交易金额

-- comment on column view_transinfo.备注 not supported: 其他说明

